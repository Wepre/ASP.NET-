﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Rel
{
    public partial class login : System.Web.UI.Page
    {
        private string sql = null;
        private SqlConnection conn = null;
        private SqlCommand cmd = null;

        private string name;
        private string password;
        protected void Page_Load(object sender, EventArgs e)
        {
            string ConnSrt = "Data Source=WINDOWS-SN3TKHN;Initial Catalog=czb;Integrated Security=True";
            conn = new SqlConnection(ConnSrt);
            conn.Open();
            //Response.Write(conn.State.ToString());
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataSourceSelectArguments ee = new DataSourceSelectArguments();
            DataView tmp = (DataView)this.SqlDataSource1.Select(ee);

            //TextBox1.Text= tmp[0][1].ToString();
            name = TextBox1.Text;
            password = TextBox2.Text;
            string sqll = "select * from users where user_name=@name and user_password=@pwd";
            
            cmd = new SqlCommand(sqll,conn);
            cmd.Parameters.AddWithValue("name",name);
            cmd.Parameters.AddWithValue("pwd", password);
            if (conn.State==ConnectionState.Closed)
            {
                conn.Open();
            }
            if (cmd.ExecuteScalar()!=null)
            {
                Session["name"] = TextBox1.Text.Trim();
               
                Response.Redirect("index.aspx", true);
            }
            else
            {
                Response.Write("<script>alert('密码错误请重新输入！')</script>");
            }
            //int i = 0;
            //for (; i < tmp.Count; i++)
            //{
            //    if (tmp[i][1].ToString().Equals(name)){
            //        break;
            //    }               
            //}
            //if(i==tmp.Count)
            //{
            //    Response.Write("<script>alert('该用户不存在')</script>");
            //}
            //else if (tmp[i][2].ToString().Equals(password))
            //{
            //    Session["name"] = TextBox1.Text.Trim();
            //    Session["headPhoto"] = tmp[i][6];
            //    Response.Redirect("index.aspx", true);
            //}


        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}