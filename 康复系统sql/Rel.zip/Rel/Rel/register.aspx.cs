﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Rel
{
    public partial class register : System.Web.UI.Page
    {
        private string sql = null;
        private SqlConnection conn = null;
        private SqlCommand cmd = null;

        private string title;
        protected void Page_Load(object sender, EventArgs e)
        {
            
            string ConnSrt = "Data Source=WINDOWS-SN3TKHN;Initial Catalog=czb;Integrated Security=True";
            conn = new SqlConnection(ConnSrt);
            conn.Open();
            //DataSourceSelectArguments ee = new DataSourceSelectArguments();
            //DataView tmp = (DataView)this.SqlDataSource1.Select(ee);

            //TextBox1.Text= tmp[0][1].ToString();
        }

        protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Panel1.Visible = false;
            Panel2.Visible = true;

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            if (CheckBoxList1.Items.Count == 0)
            {             
                
                Response.Write("<script>alert('请选择你的职位')</script>");
            }
            else
            {
                title = null;
                for (int i = 0; i < CheckBoxList1.Items.Count; i++)
                {
                    if (CheckBoxList1.Items[i].Selected)
                    {
                        title += CheckBoxList1.Items[i].Text + ",";
                    }
                }
            }

            //上传头像
            if (FileUpload1.HasFile)
            {
                string fileExrensio = System.IO.Path.GetExtension(FileUpload1.FileName).ToLower();//ToLower转化为小写
                string FileType = FileUpload1.PostedFile.ContentType;
                string UploadURL = Server.MapPath("~/upload/");//上传的目录
                if (FileType == "image/bmp" || FileType == "image/gif" || FileType == "image/jpeg" || FileType == "image/jpg" || FileType == "image/png")//判断文件类型
                {

                    try
                    {
                        if (!System.IO.Directory.Exists(UploadURL))//判断文件夹是否已经存在
                        {
                            System.IO.Directory.CreateDirectory(UploadURL);//创建文件夹
                        }

                        FileUpload1.PostedFile.SaveAs(UploadURL + FileUpload1.FileName);

                    }
                    catch
                    {
                        Response.Write("<script>alert('上传错误！')</script>");
                    }
                }
                else
                {
                    Response.Write("<script>alert('格式错误！')</script>");

                }
            }
            else
                Response.Write("<script>alert('请选择图片！')</script>");


            Random ran = new Random();
            int RandKey = ran.Next(10000000, 99999999);
            cmd = new SqlCommand("insert into doctors values (@doctor_id,@doctor_name,@doctor_password,@doctor_tel,@doctor_title,@doctor_describe,@doctor_headPhoto)", conn);
            cmd.Parameters.AddWithValue("@doctor_id", RandKey.ToString());
            cmd.Parameters.AddWithValue("@doctor_name", TextBox1.Text);
            cmd.Parameters.AddWithValue("@doctor_password", TextBox2.Text);
            cmd.Parameters.AddWithValue("@doctor_tel", TextBox4.Text);
            cmd.Parameters.AddWithValue("@doctor_title", title);
            cmd.Parameters.AddWithValue("@doctor_describe", txt1.Text);
            cmd.Parameters.AddWithValue("@doctor_headPhoto", FileUpload1.FileName);

            if(title == null)
            {
                //Response.Redirect("register.aspx", true);
                Response.Write("<script>alert('请选择你的职位')</script>");
            }
            else
            {

                if (cmd.ExecuteNonQuery() > 0)
                {
                    Response.Redirect("login.aspx", true);
                    Response.Write("<script>alert('0.0')</script>");
                }
                else
                {
                    Response.Write("<script>alert('请重新填写信息')</script>");
                    Response.Redirect("register.aspx", true);
                }
            }
            //Response.Redirect("login.aspx", true);
        }



        protected void user_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (this.txt1.Text.Length > 8 || this.txt1.Text.Length > 8)
                args.IsValid = true;
            else
                args.IsValid = false;
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}