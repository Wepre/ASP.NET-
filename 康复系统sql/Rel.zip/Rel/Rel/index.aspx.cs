﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Data;

namespace Rel
{
    public partial class index : System.Web.UI.Page
    {
        private string sql = null;
        private SqlConnection conn = null;
        private SqlCommand cmd = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Label1.Text = Session["name"].ToString();
            

            string ConnSrt = "Data Source=WINDOWS-SN3TKHN;Initial Catalog=REL;Integrated Security=True";
            conn = new SqlConnection(ConnSrt);
            conn.Open();
            //Response.Write(conn.State.ToString());
        }



        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


        protected void Button1_Click1(object sender, EventArgs e)
        {
            Response.Redirect("不存在的页面.aspx", true);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
        }
    }
}