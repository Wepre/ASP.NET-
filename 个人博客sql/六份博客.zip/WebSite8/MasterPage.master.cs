﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //在模板页中对session的User变量判断，显示出用户名
        if (Session["UserName"] != null)
        {
            this.LoginLinkButton.Visible = false;
            this.RegisterLinkButton.Visible = false;
            this.labUser.Visible = true;
            this.btnExitUser.Visible = true;
            this.labUser.Text = "欢迎您," + Session["UserName"].ToString();
        }
        else
        {
            this.btnExitUser.Visible = false;
            this.labUser.Visible = false;
        }
    }
    protected void btnExitUser_Click(object sender, EventArgs e)
    {
        MessageBox message = new MessageBox();

        if (Session["UserName"] != null)
        {
            Session["UserName"] = null;
            Response.Write(message.SendMessageBox("退出成功", "/"+
                ConfigurationManager.AppSettings["FileFloderName"].ToString() +     //加上该网站的文件夹名
                "/Blog/Index.aspx"));
        }
    }
}
