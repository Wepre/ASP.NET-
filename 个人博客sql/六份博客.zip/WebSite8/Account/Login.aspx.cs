﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;


public partial class Account_Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        DB db = new DB();
        MessageBox message = new MessageBox();
        string userName = this.txtboxUserName.Text.Trim();
        string passWord = this.txtboxPassWord.Text.Trim();
        SqlDataReader dr = db.reDr("SELECT * FROM tb_User WHERE UserName='"
            +userName+"' AND PassWord='"+passWord+"'");
        dr.Read();
        if (dr.HasRows)
        {
            Session["UserName"] = userName;     //用session保存用户名，作为全局使用
            Response.Write(message.SendMessageBox("登陆成功", "../Blog/Index.aspx"));
        }
        else
        {
            Response.Write(message.SendMessageBox("登陆失败", "Login.aspx"));
        }
        dr.Close();

        
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Account/Register.aspx");
    }
}