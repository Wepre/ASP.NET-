﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Account_register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        DB db = new DB();
        MessageBox box = new MessageBox();
        string userName = this.txtboxUserName.Text.Trim();
        string passWord1 = this.txtboxPassWord.Text.Trim();
        string passWord2 = this.txtboxPassWord2.Text.Trim();
        string email = this.txtboxEmail.Text.Trim();
        int res;

        //判断用户名是否已经注册了
        SqlDataReader dr = db.reDr("SELECT * FROM tb_User WHERE UserName='"
            +userName+"'");
        dr.Read();
        if (dr.HasRows) //该账号已经被注册
        {
            //Response.Write("该账号已经被注册");
            Response.Write(box.SendMessageBox("该账号已经被注册", "register.aspx"));
            this.txtboxUserName.Text = string.Empty;
            dr.Close();
            return;
        }
        dr.Close();

        //查询tb_user表中的记录数，从而确定用户的ID号:(select count(*) from tb_User)
        string cmdStr = "INSERT INTO tb_User(ID,UserName,PassWord,Email,IsAdmin) VALUES((select count(*) from tb_User)+1,'"
        +userName+  "','"  +
        passWord1+  "','"   + 
        email+  "',1);";

        try
        {
            res = db.sqlEx(cmdStr);
            if (res == 1)
            {
                //执行成功    
                Response.Write(box.SendMessageBox("注册成功", "Login.aspx"));
            }
            else
            {
                Response.Write(box.SendMessageBox("注册失败", "register.aspx"));
            }
        }
        catch(Exception ee){
            Response.Write(box.SendMessageBox("注册失败", "register.aspx"));
        }
    }
}