SELECT Subject,Author,Context
FROM tb_Article
WHERE ArticleID = 003