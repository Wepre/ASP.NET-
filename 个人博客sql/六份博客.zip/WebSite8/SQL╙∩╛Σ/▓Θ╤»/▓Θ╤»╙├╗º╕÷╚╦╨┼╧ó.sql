SELECT ID,UserName,Email,IsAdmin
FROM tb_User
WHERE UserName = 'yin'