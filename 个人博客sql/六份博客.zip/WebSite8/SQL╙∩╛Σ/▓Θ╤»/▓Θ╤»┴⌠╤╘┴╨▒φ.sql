SELECT Subject,Author,Context,Time
FROM tb_Revert
