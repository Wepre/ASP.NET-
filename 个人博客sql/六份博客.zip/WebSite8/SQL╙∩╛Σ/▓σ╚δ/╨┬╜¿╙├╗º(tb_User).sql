INSERT 
INTO tb_User(ID,UserName,PassWord,Email,IsAdmin) 
VALUES( (select count(*) from tb_User)+1,'yin3',123,'123@qq.com',1);
