DROP TABLE tb_Article;

CREATE TABLE tb_Article(
 ArticleID INT ,
 Author NVARCHAR(50),
 Subject NVARCHAR(50) PRIMARY KEY,
 Context NTEXT,
 Time DATETIME
);