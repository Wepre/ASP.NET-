--DROP TABLE tb_Photo;

CREATE TABLE tb_Photo(
 PhotoID INT PRIMARY KEY,
 Author NVARCHAR(50),
 Subject NVARCHAR(50),
 Context NTEXT,
 Time DATETIME
);