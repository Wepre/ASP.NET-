--DROP TABLE tb_Revert;

CREATE TABLE tb_Revert(
 RevertID INT PRIMARY KEY,
 Author NVARCHAR(50),
 Subject NVARCHAR(50),
 Context NTEXT,
 ArticleID INT ,
 PhotoID INT,
 Time DATETIME
);