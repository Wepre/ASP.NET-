UPDATE tb_User
SET UserName = 'yin3',Email = 'yin3@qq.com'
WHERE UserName = 'yin'