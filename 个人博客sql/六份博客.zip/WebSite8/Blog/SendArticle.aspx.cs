﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Blog_SendArticle : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSend_Click(object sender, EventArgs e)
    {
        string strSubject = this.txtboxTitle.Text.Trim();
        string strContext = this.txtboxContext.Text.Trim();
        string strUser = "匿名";
        int res;
        DB db = new DB();
        MessageBox message = new MessageBox();

        //假如有登陆了用户，就使用用户名来作为作者来发表文章
        if (Session["UserName"] != null)
        {
            strUser = Session["UserName"].ToString();
        }

        string strSql = "INSERT INTO tb_Article(ArticleID,Author,Subject,Time,Context) " +
        "VALUES((SELECT COUNT(*) FROM tb_Article)+1,'" +
        strUser + "', '" 
        + strSubject + "'," +
        "'"+DateTime.Now.ToString() + "'," +
        "'"+ strContext + "')";

        try
        {
            res = db.sqlEx(strSql);
            if (res == 1)
            {
                Response.Write(message.SendMessageBox("发表文章成功", "ArticleManager.aspx"));
            }
            else
            {
                Response.Write(message.SendMessageBox("发表文章失败", "SendArticle.aspx"));
            }
        }
        catch (Exception ee)
        {
            Response.Write(message.SendMessageBox("发表文章失败", "SendArticle.aspx"));
        }



    }
}