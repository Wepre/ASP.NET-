﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Blog_Massage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //DB db = new DB();
        //string strSql = "SELECT Subject,Author,Context,Time FROM tb_Revert";

        //SqlDataReader dr = db.reDr(strSql);
        //dr.Read();


    }

    protected void btnSend_Click(object sender, EventArgs e)
    {
        DB db = new DB();
        MessageBox message = new MessageBox();
        int res = 0;

        string strSubject = this.txtboxSubject.Text.Trim();
        string strContent = this.txtboxContent.Text.Trim();
        string strAuthor = "匿名";

        if (Session["UserName"] != null)
        {
            strAuthor = Session["UserName"].ToString();
        }

        string strSql = "INSERT INTO tb_Revert (RevertID,Author,Subject,Time,Context) " +
        "VALUES((SELECT COUNT(*) FROM tb_Revert)+1,'" + strAuthor + "', '" +
        strSubject +"','" + 
        DateTime.Now.ToString() + "','" +
        strContent + "')";



        try
        {
            res = db.sqlEx(strSql);
            if (res == 1)
            {
                Response.Write(message.SendMessageBox("发表留言成功", "Massage.aspx"));
            }
            else
            {
                Response.Write(message.SendMessageBox("发表留言失败", "Massage.aspx"));
            }
        }
        catch (Exception ee)
        {
            Response.Write(message.SendMessageBox("发表留言失败", "Massage.aspx"));
        }

    }
}