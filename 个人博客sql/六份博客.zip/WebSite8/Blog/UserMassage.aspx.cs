﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;

public partial class Blog_UserMassage : System.Web.UI.Page
{
    //查询本用户信息
    protected void Page_Load(object sender, EventArgs e)
    {
        DB db = new DB();
        MessageBox message = new MessageBox();

        //如果还没有登陆
        if (Session["UserName"] == null)
        {
            Response.Write(message.SendMessageBox("请登陆后再查询","/"+
                ConfigurationManager.AppSettings["FileFloderName"].ToString() +     //加上该网站的文件夹名
                "/Account/Login.aspx"));
            return;
        }

        string strSql = "SELECT ID,UserName,Email,IsAdmin FROM tb_User WHERE UserName = '"+ 
            Session["UserName"].ToString() + "'";
        SqlDataReader dr = db.reDr(strSql);
        dr.Read();

        this.txtboxUserID.Text = dr.GetValue(0).ToString();
        this.txtboxUserName.Text = dr.GetValue(1).ToString();
        this.txtboxEmail.Text = dr.GetValue(2).ToString();
        if (dr.GetValue(3).ToString() == "1")
        {
            this.txtboxAdmin.Text = "是";
        }
        else
        {
            this.txtboxAdmin.Text = "否";
        }


    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        DB db = new DB();
        MessageBox message = new MessageBox();
        int res = 0;

        string strSql = "SELECT ID,UserName,Email,IsAdmin FROM tb_User WHERE UserName = '" +
            Session["UserName"].ToString() + "'";
        SqlDataReader dr = db.reDr(strSql);
        dr.Read();

        //如果有修改到
        if ((this.txtboxUserName.Text != dr.GetValue(1).ToString())
            || (this.txtboxEmail.Text != dr.GetValue(2).ToString()))
        {
            strSql = "UPDATE tb_User SET UserName = '" + this.txtboxUserName.Text +
                "',Email = '" + this.txtboxEmail.Text + "' WHERE UserName = '" +
                Session["UserName"].ToString() + "'";
            try
            {
                res = db.sqlEx(strSql);
                if (res == 1)
                {
                    Response.Write(message.SendMessageBox("修改成功", "UserMassage.aspx"));
                }
                else
                {
                    Response.Write(message.SendMessageBox("修改失败", "UserMassage.aspx"));
                }
            }
            catch (Exception ee)
            {
                Response.Write(message.SendMessageBox("修改失败", "UserMassage.aspx"));
            }
        }
        else
        {
            Response.Write(message.SendMessageBox("修改信息没有变动", "UserMassage.aspx"));
        }
        
        

    }
}