﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;


public partial class Blog_ShowArticle : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        DB db = new DB();

        string ArticleID = Page.Request["ArticleID"];
        string sqlStr = "SELECT Subject,Author,Context FROM tb_Article WHERE ArticleID = " + ArticleID;

        SqlDataReader dr = db.reDr(sqlStr);
        dr.Read();

        this.labSubject.Text = dr.GetValue(0).ToString() ;
        this.labAuthor.Text = "作者：" + dr.GetValue(1).ToString();
        this.TxtContent.Text = dr.GetValue(2).ToString();

    }
}